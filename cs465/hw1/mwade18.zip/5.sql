SELECT price, type FROM Room;
