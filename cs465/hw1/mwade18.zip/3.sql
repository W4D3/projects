SELECT COUNT(hotelNo) FROM Hotel;
