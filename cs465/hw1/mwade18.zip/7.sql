SELECT hotelNo, COUNT(*) AS count FROM Room GROUP BY HotelNo;
