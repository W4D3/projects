SELECT SUM(price) FROM Room WHERE type='double';
