SELECT hotelName, COUNT(*) AS count FROM Hotel WHERE city='London';
