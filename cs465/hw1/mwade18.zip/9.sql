UPDATE Room SET price = price*0.05+price;
