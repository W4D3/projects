SELECT * FROM Room WHERE type='double' OR type='family' AND price<40;
