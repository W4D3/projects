# comparator.py
# Mitchell Wade
# March 31, 2015
# This function is a comparator that returns true
# if the specified two values are equal and false
# otherwise.

def comparator(value1, value2):
    if value1 == value2:
        return True
    else:
        return False

